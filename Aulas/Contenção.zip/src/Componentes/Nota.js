import React, { Component } from 'react';

function Nota(props) {
    return(
        <div>
            <legend>Informe a nota: {props.num} </legend>
            <input type='text' name={props.num} value={props.nota} onChange={(e)=>props.setNota(e)}></input>
        </div>
    )
}

export default Nota;