import React from 'react';

function Caixa(props) {
    
        return (
            <div>
                {props.nome}
                {props.children}
            </div>
        );
    
}

export default Caixa;