import React,{useState,useEffect} from 'react';
import Caixa from './Componentes/Caixa';


export default function App(){

  return (
    <div>
      <Caixa nome='Bruno'>
        <h1>To com fome</h1>
        <p>Para que você tá ficando gordo</p>
      </Caixa>
    </div>
  );
  
}

/*
  //La em caixa será chamado o {props.childen} que irá passar o
  //O que está dentro de Caixa

  //Children é um array, então se quiser chamar um elemento especifico
  //É só chamar {props.childen[0]}
*/