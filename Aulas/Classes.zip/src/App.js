import React from 'react';
import Classe from './Componentes/Classe';

export default function App(){

  return (
    <div>
      <h1>Componentes de função</h1>
      <Classe nome='Bruno' sobrenome='Guedes'/>
    </div>
  );
  
}

/*
  
*/