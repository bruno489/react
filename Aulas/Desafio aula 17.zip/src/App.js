import React,{useState,useEffect} from 'react';
import Nota from './Componentes/Nota';
import Resultado from './Componentes/Resultado'


export default function App(){

  const [nota,setNota]=useState({'nota1':'10','nota2':'0','nota3':'0','nota4':'0'});
  const handleNotas=(e)=>{
    if(e.target.getAttribute('name')==1){
      setNota({
      'nota1':e.target.value,
      'nota2':nota.nota2,
      'nota3':nota.nota3,
      'nota4':nota.nota4
    })
  }else if(e.target.getAttribute('name')==2){
      setNota({
      'nota1':nota.nota1,
      'nota2':e.target.value,
      'nota3':nota.nota3,
      'nota4':nota.nota4
    })
    }else if(e.target.getAttribute('name')==3){
      setNota({
      'nota1':nota.nota1,
      'nota2':nota.nota2,
      'nota3':e.target.value,
      'nota4':nota.nota4
    })
    }else if(e.target.getAttribute('name')==4){
      setNota({
      'nota1':nota.nota1,
      'nota2':nota.nota2,
      'nota3':nota.nota3,
      'nota4':e.target.value
    })
    }
  }

  return (
    <div>
      <Nota num={1} nota={nota.nota1} setNota={handleNotas} />
      <Nota num={2} nota={nota.nota2} setNota={handleNotas} />
      <Nota num={3} nota={nota.nota3} setNota={handleNotas} />
      <Nota num={4} nota={nota.nota3} setNota={handleNotas} />
      <Resultado somaNotas={parseFloat(nota.nota1)+parseFloat(nota.nota2)+parseFloat(nota.nota3)+parseFloat(nota.nota4)}/>
    </div>
  );
  
}

/*
  parseFloat(variavel ou string ou state)
  transforma de string em numero com ou sem virgula

  //Elevação de state é simplemente repassar o mesmo props para conteudos diferentes
*/