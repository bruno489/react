import React, { Component } from 'react';

class Carro extends Component {
    constructor(props){
        super(props)
        this.modelo='Golf'
        this.state={
            ligado:false,
            velocidadeAtual:0
        }
        this.funcao=this.ligar.bind(this)
        //bind nada mais é do que um elemento responsavel por ligar
        //outro elemento ou função.
    }
    ligar(){
        this.setState(
            (state)=>(
                {ligado:!state.ligado}
            )
        )
    }

    acelerar(){
        this.setState(
            (state,props)=>(
                {velocidadeAtual:this.state.velocidadeAtual + this.props.fator}
            )
        )
    }

    render() {
        return (
            <div>
                <h1>Meu Carro</h1>
                <p>Modelo: {this.modelo}</p>
                <p>Ligado:{this.state.ligado?'Sim':'Não'}</p>
                <p>Velocidade Atual:{this.state.velocidadeAtual}</p>
                <button onClick={this.funcao}>{this.state.ligado?'Desligar':'Ligar'}</button>
                
                <button onClick={()=>this.acelerar()}>Acelerar</button>
            </div>
        );
    }
    //Vejá vem que a função foi subtituida pelo bind que está ligado ao ligar()
}

export default Carro;