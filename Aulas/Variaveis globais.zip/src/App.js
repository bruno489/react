import React, { useState } from 'react';
import Globais from './Componentes/Globais';

export default function App(){

  const [resumo,setResumo]=useState(Globais.resumo)

  const gravaResumo=()=>{
    Globais.resumo=resumo;
  }

  const veResumo=()=>{
    alert(Globais.resumo)
  }

  return (
    <div>
      <p>{'Canal: '+ Globais.canal}</p>
      <p>{'Curso: '+ Globais.curso}</p>
      <p>{'Ano: '+ Globais.ano}</p>
      <hr/>
      <input type='text' size='100' value={resumo} onChange={(e)=>setResumo(e.target.value)}></input>
      <br/><button onClick={()=>gravaResumo()}>Gravar Resumo</button>
      <button onClick={()=>veResumo()}>Ver Resumo</button>
    </div>
  );
  
}

/*
  Lembrar que são variaveis e tem que atualizar a pagina
  para que seja renderizado.
  Só os states podem ser renderizados assim que modificados

  Tudo vem da classe de do Globais.js
*/