import React, { Component } from 'react';

class Globais extends Component {
    static canal='CFB cursos'
    static curso= 'Curso de react'
    static ano=2021
    static resumo='Curso de react do canal do...'

    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default Globais;