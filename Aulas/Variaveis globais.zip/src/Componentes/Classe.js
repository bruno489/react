import React, { Component } from 'react';

class Classe extends Component {

    constructor(props){
        super(props)
        //O super() chama o construtor da classe pai (react.component)
        //Aqui todos os props já foram transformados
    }

    render() {
        return (
            <div>
                <h1>Primeiro componente de classe</h1>
                <p>Nome: {this.props.nome} {this.props.sobrenome}</p>
            </div>
            //na função se usa somente o props.nome
            //Aqui o this.props.nome
        );
    }
}

export default Classe;

/*
Para capturar os props, deve-se usar o constructor
*/