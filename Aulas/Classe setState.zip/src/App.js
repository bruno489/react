import React from 'react';
import Carro from './Componentes/Carro';

export default function App(){

  return (
    <div>
      <h1>Componentes de função</h1>
      <Carro />
    </div>
  );
  
}

/*
  
*/