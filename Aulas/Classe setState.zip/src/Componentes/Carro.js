import React, { Component } from 'react';

class Carro extends Component {
    constructor(){
        super()
        this.modelo='Golf'
        //Variavel comum do constructor
        this.state={
            ligado:false,
            velocidadeAtual:0
        }
    }
    ligar(){
        this.setState({ligado:!this.state.ligado})
        //this.setState({ligado:true})
        //é assim que se atualiza um state em classe e a renderiza

        //this.setState({ligado:!this.state.ligado})
        //A exclamação muda o conteudo anterior para seu inverso/negativa
    }
    render() {
        return (
            <div>
                <h1>Meu Carro</h1>
                <p>Modelo: {this.modelo}</p>
                <p>Ligado:{this.state.ligado?'Sim':'Não'}</p>
                <p>Velocidade Atual:{this.state.velocidadeAtual}</p>
                <button onClick={()=>this.ligar()}>{this.state.ligado?'Desligar':'Ligar'}</button>
            </div>
        );
    }
    //Prestar maxima atenção no this para chamar uma função
}

export default Carro;