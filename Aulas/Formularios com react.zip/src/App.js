import React,{useState,useEffect} from 'react';


export default function App(){

  const [nome,setNome]=useState('');
  const [carro,setCarro]=useState('GOLF')

  return (
    <div>
      <label>Digite nome: </label>
      <input 
        type='text' 
        name='fnome'
        value={nome}
        onChange={(e)=>setNome(e.target.value)}
        />
      <p>Nome Digitado: {nome}</p>

      <label>Selecione um carro: </label>
      <select value={carro} onChange={(e)=>setCarro(e.target.value)}>
        <option value='HRV'>HRV</option>
        <option value='GOLF'>GOLF</option>
        <option value='CRUSE'>CRUSE</option>
        <option value='ARGO'>ARGO</option>
      </select>

      <p>Carro selecionado: {carro}</p>
    </div>
  );
  
}

/*
  const [nome,setNome]=useState('aline');

  <input 
    type='text' 
    name='fnome'
    value={nome}
    onChange={(e)=>setNome(e.target.value)}
  />
  <p>Nome Digitado: {nome}</p>
  'e' já é uma expressão que passa o valor do input
  e.target.value ta passando para a constante 'nome' o valor
  do input

  |----------------------------------------------------------|

  const [nome,setNome]=useState('aline');
  const handleChangeNome=(e)=>{
    setNome(e.target.value)
  }

  return (
    <div>
      <label>Digite nome: </label>
      <input 
        type='text' 
        name='fnome'
        value={nome}
        onChange={(e)=>handleChangeNome(e)}
        />
      <p>Nome Digitado: {nome}</p>
    </div>
  );

  mudar usando um manipulador handle

  |----------------------------------------------------------|


*/