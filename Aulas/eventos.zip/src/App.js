import React,{useState,useEffect} from 'react';
import Led from './Componentes/Led.js';

export default function App(){

  const [ligado,setLigado]=useState(false);

  return (
    <div>
      <Led ligado={ligado} setLigado={setLigado}/>
    </div>
  );
  
}

