import React, {useState} from 'react';

const carros = [
  {categoria:'Esport',preco:'300000',modelo:'Golf'},
  {categoria:'Esport',preco:'124000',modelo:'CAMARO'},
  {categoria:'SUV',preco:'82000',modelo:'HRV'},
  {categoria:'SUV',preco:'32000',modelo:'T-CROSS'},
  {categoria:'UTILITARIO',preco:'44000',modelo:'HILUX'},
  {categoria:'UTILITARIO',preco:'99000',modelo:'RANGER'},
]

const linhas = (cat)=>{
  const li=[]
  carros.forEach(
    (carro)=>{
      if (carro.categoria.toUpperCase()==cat.toUpperCase() || cat.toUpperCase()=='') {
        li.push(
          <tr>
            <td>{carro.categoria}</td>
            <td>{carro.preco}</td>
            <td>{carro.modelo}</td>
          </tr>
        )
      }
    }
  )
  return li
}

const tabelaCarro=(cat)=>{
  return(
    <table border='1' style={{borderCollapse:'collapse'}}>
      <thead>
        <tr>
          <th>Categoria:</th><th>Preço:</th><th>Modelo:</th>
        </tr>
      </thead>
      <tbody>
        {linhas(cat)}
      </tbody>
    </table>
  )
}
const pesquisaCategoria=(cat,scat)=>{
  return(
    <div>
      <label>Digite uma categoria:</label>
      <input type='text' value={cat} onChange={(e)=>scat(e.target.value)}></input>
    </div>
    )
}

export default function App(){
  const [categoria, setCategoria]=useState('')

  return (
    <div>
      {pesquisaCategoria(categoria,setCategoria)}
      {tabelaCarro(categoria)}
    </div>
  );
  
}

/*
  
*/