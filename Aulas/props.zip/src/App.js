import React,{useState,useEffect} from 'react';
import './Css/index.css';
import Header from './Componentes/Header';
import Corpo from './Componentes/Corpo';
import Dados from './Componentes/Dados';

export default function App(){

  const cnl = 'CFB';
  const yt = 'Tamo aí';
  const crs = 'React';
  
  return (
    <div>
      <Header />
      <Corpo />
      <Dados canal={cnl} curso={yt} youtube={crs} />
    </div>
  );
  
}
