import React, { Component } from 'react';

export default function Dados(props) {

        

        return (
            <div>
                <p>Canal: {props.canal}</p>
                <p>YouTube: {props.youtube}</p>
                <p>Curso: {props.curso}</p>
            </div>
        );
}
