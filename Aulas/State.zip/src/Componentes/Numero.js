import React from 'react'


export default function Numero(props) {
    return(
        <div>
            <p>Valor do state num: {props.num}</p>
            <button onClick={()=>props.setNum(props.num+10)}>100</button>
        </div>
    )
}

//trasendo e transmitindo ao app