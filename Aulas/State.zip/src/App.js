import React,{useState,useEffect} from 'react';
import './Css/App.css';
import Numero from './Componentes/Numero';
//import Header from './Componentes/Header';
//import Corpo from './Componentes/Corpo';
//import Dados from './Componentes/Dados';

export default function App(){

  const[num,setNum] = useState(10);
  
  return (
    <div>
      <p>Valor do state num em App: {num}</p>
      <Numero num={num} setNum={setNum}/>
    </div>
  );
  
}

/*
const[nome do state,nome da função que altera o state e exibe] = useState();
useState();
É o que define como um state

Quando se usa variavel, o valor atribuido a variavél não é atualizado
e mostrado na tela, diferente do state.
Vai dormir que tu ta com sono.

<button onClick={()=>setNum(100)}>100</button>
o setNum é a forma de alterar o conteudo, o que tem dentro de setNum()
será o conteudo adicionado

<button onClick={()=>setNum(num+10)}>100</button>
adiciona o valor a constante anterior

<Numero num={num} setNum={setNum}/>
num={valores da constantte}
setNum={o que vai ser chamado para adicionar}

*/