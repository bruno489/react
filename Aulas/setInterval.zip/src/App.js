import React,{useState,useEffect} from 'react';
import './Css/App.css';
import Relogio from './Componentes/Relogio';
//import Header from './Componentes/Header';
//import Corpo from './Componentes/Corpo';
//import Dados from './Componentes/Dados';

export default function App(){

  const destaque={
    color:'blue',
    fontSize:'40px',
    
  }
  
  return (
    <div>
      <Relogio />
      <h1 style={{color:'red', fontSize:'60px'}}>CFB Cursos</h1>
      <h2 style={destaque}>Cursos de React</h2>
      <p className='texto'>Se inscreva em nosso canal</p>
    </div>
  );
  
}

//style={{color:'red', fontSize:'60px'}}
//usa a virgula para separar

/*
const destaque={
    color:'blue',
    fontSize:'40px' 
  }
<h2 style={destaque}>Cursos de React</h2>

Se externo, você tem que importar o arquivo.

DAR PREFERENCIA A UTILIZAÇÃO DE CLASSES
*/