import React, { Component } from 'react';

class Relogio extends Component {
    render() {
        return (
            <div>
                <p>
                    {new Date().toLocaleTimeString()}
                </p>
            </div>
        );
    }
}

export default Relogio;