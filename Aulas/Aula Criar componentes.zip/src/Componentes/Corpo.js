import React, { Component } from 'react';

class Corpo extends Component {
    render() {
        return (
            <div>
                <section>
                    <h2>Curso de React</h2>
                    <p>Se inscreva</p>
                </section>
            </div>
        );
    }
}

export default Corpo;