import React,{useState,useEffect} from 'react';
import './Css/index.css';
import Header from './Componentes/Header';
import Corpo from './Componentes/Corpo';

export default function App(){
  
  return (
    <div>
      <Header />
      <Corpo />
    </div>
  );
  
}
