import React from "react";


export default function Pagina1() {
    return(
        <div>
            <h1>Pagina 3</h1>
            <h3>React Router</h3>
        </div>
    )
}