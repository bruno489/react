import React from "react";

export default function Pagina1() {
    return(
        <div>
            <h1>Pagina 1</h1>
            <h3>Curso de react</h3>
        </div>
    )
}