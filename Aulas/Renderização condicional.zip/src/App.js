import React, {useState} from 'react';



function ListaNumeros() {
  const hora =19;
  if (hora>=0 && hora <=13) {
    return (<p>Bom dia</p>)
  } else if (hora>=14 && hora <=17){
    return (<p>Bom tarde</p>)
  }else{
    return (<p>Boa Noite</p>)
  }
}

export default function App(){
  
  return (
    <div>
      {ListaNumeros()}
    </div>
  );
  
}

/*
  condicional aí
*/