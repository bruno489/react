import React from "react"

export default function Pagina2() {
    return(
        <div>
            <h1>Pagina 2</h1>
            <h3>CFB Cursos</h3>
        </div>
    )
}