import React, {useState} from 'react';
import { Switch,Route,Link } from "react-router-dom";
import Pg1 from './Componentes/Pagina1';
import Pg2 from './Componentes/Pagina2';
import Pg3 from './Componentes/Pagina3';

export default function App(){
  
  return (
    <div>
      <header>
        <Link to='/'>home</Link>
        <Link to='/pag1'>Pagina 1</Link>
        <Link to='/pag2'>Pagina 2</Link>
        <Link to='/pag3'>Pagina 3</Link>
        
      </header>
      <main>
        <Switch>
          <Route path='/pag1' component={Pg1}/>
          <Route path='/pag2' component={Pg2}/>
          <Route path='/pag3' component={Pg3}/>
          <Route path='/' component={Pg1}/>
        </Switch>
      </main>
      
    </div>
  );
  
}

/*
  npm install --save react-router-dom
  instala o dom para o router

  //Switch
  //É o comando que faz o controle das rotas

  <Route path='nome da url que vai abrir o caminha' component={}/>

  <Link to='endereço inserido'>home</Link>
  Tem a mesma função de ancoragem do <a></a>
*/