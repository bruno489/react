import React,{useState,useEffect} from 'react';
import './Css/index.css';
import Header from './Componentes/Header';
import Corpo from './Componentes/Corpo';
import Dados from './Componentes/Dados';

export default function App(){

  const cnl =()=>{return 'CFB'; } 
  const yt = ()=>{return 'Tamo aí'; } 
  const crs = ()=>{return 'React';} 
  const somar =(v1,v2)=>{
    return v1+v2
  }

  return (
    <div>
      <Header />
      <Corpo />
      <Dados canal={cnl} curso={yt} youtube={crs} somar={somar} />
    </div>
  );
  
}
