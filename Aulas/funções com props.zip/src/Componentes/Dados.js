import React, { Component } from 'react';

export default function Dados(props) {
    const n1=10;
    const n2=5;
        

        return (
            <div>
                <p>Canal: {props.canal()}</p>
                <p>YouTube: {props.youtube()}</p>
                <p>Curso: {props.curso()}</p>
                <p>{'a soma de' + n1 +' + ' + n2 + ' = '}{props.somar(n1,n2)}</p>
            </div>
        );
}
//Aqui o atributo tem que ser chamado como função