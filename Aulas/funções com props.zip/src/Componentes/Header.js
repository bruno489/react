import React, { Component } from 'react';
import imagem from './imgs/logo.png';

class Header extends Component {
    render() {
        return (
            <div>
                <header>
                    <img src={imagem}></img>
                    <h1>CFB CURSOS</h1>
                </header>
            </div>
        );
    }
}

export default Header;