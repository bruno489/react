import React from 'react'


export default function Numero(props) {
    return(
        <div>
            <p>Valor do state num: {props.num}</p>
            <button onClick={()=>props.setNum(props.num+props.num)}>{props.num}</button>
        </div>
    )
}

//trasendo e transmitindo ao app