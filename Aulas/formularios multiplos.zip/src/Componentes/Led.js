import React,{useState,useEffect} from 'react';
import camisa1 from './imgs/camisa1F.png'
import camisa2 from './imgs/camisa6F.png'

export default function Led(props){

  return (
    <div>
      <img src={props.ligado? camisa1:camisa2}></img>
      <button onClick={()=>props.setLigado(!props.ligado)}>
          {props.ligado? 'Azul':'Vermelho'}</button>
    </div>
  );
  
}

/*

const [ligado,setLigado]=useState(false);

<img src={ligado? camisa1:camisa2}></img>
<button onClick={()=>setLigado(!ligado)}>Mudar</button>
precisa falar algo? o setState alterou a constante invertendo-a

*/