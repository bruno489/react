import React,{useState,useEffect} from 'react';


export default function App(){

  const [form,setForm]=useState({'nome':'','curso':"",'ano':""});

  const handleFormChange=(e)=>{
    if(e.target.getAttribute('name')=='fnome'){
      setForm({'nome':e.target.value,'curso':form.curso,'ano':form.ano})
    }else if(e.target.getAttribute('name')=='fcurso'){
      setForm({'nome':form.nome,'curso':e.target.value,'ano':form.ano})
    }else if(e.target.getAttribute('name')=='fano'){
      setForm({'nome':form.nome,'curso':form.curso,'ano':e.target.value})
    }
  }
  //Se a o nome do input for nome, então acrescentará no state o referido valor
  //deve ser chamado o state completo

  return (
    <div>
      <label>Digite nome: </label>
      <input type='text' name='fnome' value={form.nome} onChange={(e)=>handleFormChange(e)} /><br/>
      <label>Curso: </label>
      <input type='text' name='fcurso' value={form.curso} onChange={(e)=>handleFormChange(e)} /><br/>
      <label>Ano: </label>
      <input type='date' name='fano' value={form.ano} onChange={(e)=>handleFormChange(e)} /><br/>

      <p>Nome digitado: {form.nome}</p>
      <p>Curso digitado: {form.curso}</p>
      <p>Ano digitado: {form.ano}</p>
    </div>
  );
  
}

/*
  const [nome,setNome]=useState('aline');

  <input 
    type='text' 
    name='fnome'
    value={nome}
    onChange={(e)=>setNome(e.target.value)}
  />
  <p>Nome Digitado: {nome}</p>
  'e' já é uma expressão que passa o valor do input
  e.target.value ta passando para a constante 'nome' o valor
  do input

  |----------------------------------------------------------|

  const [nome,setNome]=useState('aline');
  const handleChangeNome=(e)=>{
    setNome(e.target.value)
  }

  return (
    <div>
      <label>Digite nome: </label>
      <input 
        type='text' 
        name='fnome'
        value={nome}
        onChange={(e)=>handleChangeNome(e)}
        />
      <p>Nome Digitado: {nome}</p>
    </div>
  );

  mudar usando um manipulador handle

  |----------------------------------------------------------|


*/