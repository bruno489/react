import React,{useState,useEffect} from 'react';

export default function App(){

  const [nome,setNome] = useState()

  const armazenar=(chave,valor)=>{
    localStorage.setItem(chave,valor)
  }

  const consultar=(chave)=>{
    alert(localStorage.getItem(chave))
  }

  const apagar = (chave)=>{
    localStorage.removeItem(chave)
  }

  return (
    <div>
      <label>Digite o nome: </label><br/>
      <input type='text' value={nome} onChange={(e)=>setNome(e.target.value)}></input><br/>
      <button onClick={()=>armazenar('ls_nome',nome)}>Gravar Nome</button>
      <button onClick={()=>consultar('ls_nome',nome)}>Ver Nome</button>
      <button onClick={()=>apagar('ls_nome')}>Remover Nome</button>
    </div>
  );
  
}

/*
  localStorage.setItem('chave','valor')
  //adiciona uma chave e valor
  //se colocar outro item com a mesma chave, o valor será trocado

  localStorage.getItem('nome')
  //Pega o valor da chave

  localStorage.removeItem('nome')
  //Remove o valor da chave
*/